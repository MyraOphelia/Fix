
//     // Student class implementation

// public class student {
//     private String id;
//     private String name;
//     private String selectedCourse;
//     private double priceBeforeDiscount;
//     private double discountAmount;
//     private double netPayable;

//     // Constructor
//     public student(String id, String name, String selectedCourse, double priceBeforeDiscount, double discountAmount, double netPayable) {
//         this.id = id;
//         this.name = name;
//         this.selectedCourse = selectedCourse;
//         this.priceBeforeDiscount = priceBeforeDiscount;
//         this.discountAmount = discountAmount;
//         this.netPayable = netPayable;
//     }

//     // Getters and Setters (You can generate these automatically in most IDEs)
//     public String getId() {
//         return id;
//     }

//     public void setId(String id) {
//         this.id = id;
//     }

//     public String getName() {
//         return name;
//     }

//     public void setName(String name) {
//         this.name = name;
//     }

//     public String getSelectedCourse() {
//         return selectedCourse;
//     }

//     public void setSelectedCourse(String selectedCourse) {
//         this.selectedCourse = selectedCourse;
//     }

//     public double getPriceBeforeDiscount() {
//         return priceBeforeDiscount;
//     }

//     public void setPriceBeforeDiscount(double priceBeforeDiscount) {
//         this.priceBeforeDiscount = priceBeforeDiscount;
//     }

//     public double getDiscountAmount() {
//         return discountAmount;
//     }

//     public void setDiscountAmount(double discountAmount) {
//         this.discountAmount = discountAmount;
//     }

//     public double getNetPayable() {
//         return netPayable;
//     }

//     public void setNetPayable(double netPayable) {
//         this.netPayable = netPayable;
//     }
// }
